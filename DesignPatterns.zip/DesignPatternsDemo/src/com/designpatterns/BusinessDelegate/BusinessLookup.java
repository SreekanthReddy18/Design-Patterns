package com.designpatterns.BusinessDelegate;

public class BusinessLookup {
  
	
	public BusinessService lookUp(String type) {
		if(type.equalsIgnoreCase("Master")) {
			return new MasterBusiness();
		}else {
			return new ChildBusiness();
		}
	}
	
}
