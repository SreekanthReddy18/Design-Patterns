package com.designpatterns.BusinessDelegate;

public interface BusinessService {

	public void processExecution();
}
