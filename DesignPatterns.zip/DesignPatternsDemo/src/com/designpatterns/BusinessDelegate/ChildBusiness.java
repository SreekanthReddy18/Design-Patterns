package com.designpatterns.BusinessDelegate;

public class ChildBusiness implements BusinessService {

	@Override
	public void processExecution() {
   System.out.println("From Child business");		
	}

}
