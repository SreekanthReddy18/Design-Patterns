package com.designpatterns.BusinessDelegate;

public class BusinessTest {

	public static void main(String[] args) {
       BusinessDelegate businessDelegate = new BusinessDelegate();
       businessDelegate.setType("xyz");
       businessDelegate.processRun();
	}

}
