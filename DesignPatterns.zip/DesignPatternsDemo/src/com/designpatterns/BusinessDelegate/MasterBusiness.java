package com.designpatterns.BusinessDelegate;

public class MasterBusiness implements BusinessService{

	@Override
	public void processExecution() {

		System.out.println("From Master Business");
		
	}

}
