package com.designpatterns.BusinessDelegate;

public class BusinessDelegate {
    BusinessLookup businessLookup;
    private String type;
    
    public BusinessDelegate() {
    	super();
    	businessLookup = new BusinessLookup();
    }

	public void setType(String type) {
		this.type = type;
	}
    public void processRun() {
    	BusinessService businessService = businessLookup.lookUp(type);
    	businessService.processExecution();
    }
}
