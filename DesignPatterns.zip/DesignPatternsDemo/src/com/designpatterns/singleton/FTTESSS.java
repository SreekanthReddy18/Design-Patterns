package com.designpatterns.singleton;

public class FTTESSS{ 
	
	private static volatile FTTESSS[] instances=new FTTESSS[5]; 
	private static  int index=0; 
	
	private FTTESSS(){} // not thread-safe 
	
	public static FTTESSS getInstance(){ 
		if(instances[index] == null) {
		  synchronized (FTTESSS.class) {
		        if(instances[index]==null){ 
			
			        instances[index]=new FTTESSS();
		        } else{ 
			        System.out.println("\nExceeded maximum number of instance"
		
				    + "s #5 \nGetting same instance#"+(index+1)); 
		          } 
	      }
	}
		FTTESSS instance=instances[index]; 
		index=(index+1)%instances.length; 
		return instance;
		
  }
} 