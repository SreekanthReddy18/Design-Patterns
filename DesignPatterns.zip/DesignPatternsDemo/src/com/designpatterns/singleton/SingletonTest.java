package com.designpatterns.singleton;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SingletonTest {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException, CloneNotSupportedException {
		SingletonDemo single;
       for(int i=10;i>=1;i--) {
    	   single=SingletonDemo.getInstance();
    	   System.out.println(+i+". Hash Code to test Singleton : "+single.hashCode());
       }
		
		/*SingletonDemo instance =SingletonDemo.getInstance();
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("D:\\Singleton.ser")));
		oos.writeObject(instance);
		SingletonDemo instance2 = null;
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File("D:\\Singleton.ser")));
		instance2=(SingletonDemo)ois.readObject();
		
		System.out.println("Actual Object "+instance.hashCode()+" After Serialization "+instance2.hashCode());
		*/
		/*System.out.println("Clone experiment"+ single.clone());*/
	}

	
	
}
