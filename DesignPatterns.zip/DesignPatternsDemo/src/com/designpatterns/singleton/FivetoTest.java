package com.designpatterns.singleton;
 
class FivetoTest { 
			public static void main (String[] args) throws java.lang.Exception { 
				FTTESSS f1=FTTESSS.getInstance(); 
				System.out.println("instance#1 = " + f1.hashCode()); 
				FTTESSS f2=FTTESSS.getInstance(); 
				System.out.println("instance#2 = " + f2.hashCode()); 
				FTTESSS f3=FTTESSS.getInstance(); 
				System.out.println("instance#3 = " + f3.hashCode()); 
				FTTESSS f4=FTTESSS.getInstance(); 
				System.out.println("instance#4 = " + f4.hashCode()); 
				FTTESSS f5=FTTESSS.getInstance(); 
				System.out.println("instance#5 = " + f5.hashCode()); 
				FTTESSS f6=FTTESSS.getInstance(); 
				System.out.println("instance#6 = " + f6.hashCode()); 
				FTTESSS f7=FTTESSS.getInstance(); 
				System.out.println("instance#7 = " + f7.hashCode()); 
				 }
}
