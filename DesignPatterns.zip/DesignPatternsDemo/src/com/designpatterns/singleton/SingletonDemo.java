package com.designpatterns.singleton;

import java.io.Serializable;

public class SingletonDemo implements Serializable,Cloneable {
  
	/**
	 * 
	 */
	private static final long serialVersionUID = 1351348789164167104L;
	
	private static volatile SingletonDemo instance;
	
	private SingletonDemo() {
		
	}
	
	public static SingletonDemo getInstance() {
		if(instance == null) {
			synchronized (SingletonDemo.class) {
				if(instance == null) {
					instance = new SingletonDemo();
				}
				
			}
		}
		return instance;
	}
	protected Object readResolve() {
		return instance;
	}
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}
}
