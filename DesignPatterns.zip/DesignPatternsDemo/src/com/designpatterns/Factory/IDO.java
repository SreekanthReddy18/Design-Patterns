package com.designpatterns.Factory;

public interface IDO {
	
	void populateObject();

}
