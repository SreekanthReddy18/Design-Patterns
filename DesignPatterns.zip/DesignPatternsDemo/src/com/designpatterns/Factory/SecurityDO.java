package com.designpatterns.Factory;

public class SecurityDO implements IDO{

	@Override
	public void populateObject() {
       System.out.println("Populated from Security");		
	}

}
