package com.designpatterns.Factory;

public class SearchFactroy {
	
	public static IDO getInstance(String moduleref) {
		IDO o = null;
		if(moduleref.equals("PORTFOLIO")) {
			o = new PortfolioDO();
		}else if(moduleref.equals("SECURITY")) {
			o = new SecurityDO();
		}else {
			System.out.println("Moduleref Type can not be empty");
		}
		return o;
	}

}
