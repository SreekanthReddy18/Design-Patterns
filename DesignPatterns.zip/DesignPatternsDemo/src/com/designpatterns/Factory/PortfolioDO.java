package com.designpatterns.Factory;

public class PortfolioDO implements IDO {

	@Override
	public void populateObject() {
    System.out.println("Populated from Portfolio");		
	}

}
