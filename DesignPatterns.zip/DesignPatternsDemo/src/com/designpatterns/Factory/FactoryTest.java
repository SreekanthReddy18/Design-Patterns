package com.designpatterns.Factory;

public class FactoryTest {

	public static void main(String[] args) {
       IDO DO = null;
      // DO = SearchFactroy.getInstance("PORTFOLIO");
       DO = SearchFactroy.getInstance("SECURITY");
       DO.populateObject();
       
	}

}
