package com.designpatterns.Adapter;

public class WeatherFinder implements IWeatherFinder {

	@Override
	public int weatherFind(String city) {
		return 38;
	}

}
