package com.designpatterns.Adapter;

public class WeatherTest {

	public static void main(String[] args) {
          IWeatherAdapter wta = new WeatherAdapter();
          System.out.println(wta.getTemp("345678"));
	}

}
