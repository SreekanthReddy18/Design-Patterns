package com.designpatterns.Adapter;

public class WeatherAdapter implements IWeatherAdapter {
	
    @Override
	public int getTemp(String zipcode) {
		String str = null;
		if(zipcode.equals("345678")) {
			 str = "Chennai";
		}
		IWeatherFinder wtf = new WeatherFinder();
		
		return wtf.weatherFind(str);
		
	}
	
	
}
