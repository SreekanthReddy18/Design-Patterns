package com.designpatterns.Adapter;

public interface IWeatherFinder {

	int weatherFind(String city);
}
