package com.designpatterns.Adapter;

public interface IWeatherAdapter {

	public int getTemp(String zipcode);
}
