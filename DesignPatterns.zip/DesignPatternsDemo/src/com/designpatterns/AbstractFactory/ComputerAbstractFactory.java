package com.designpatterns.AbstractFactory;

public interface ComputerAbstractFactory {

	public Computer createComputer();

}