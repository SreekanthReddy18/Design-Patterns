package com.designpatterns.AbstractFactory;

public class ComputerFactory {

	public static Computer getComputer(ComputerAbstractFactory factory){
		System.out.println("Computer Factory");
		return factory.createComputer();
	}
}